public class GroceryMain
{
   public static void main(String[] args)
   { 
      GroceryItemOrder cookies = new GroceryItemOrder("cookies", 1, 3.99);
      GroceryItemOrder milk = new GroceryItemOrder("milk", 2, 2.49);
      GroceryItemOrder pop = new GroceryItemOrder("pop", 4, 4.99);
      GroceryItemOrder pizza = new GroceryItemOrder("pizza", 4, 9.99);
      GroceryItemOrder iceCream = new GroceryItemOrder("ice cream", 3, 7.99);
   
      GroceryList party = new GroceryList();
   
      party.add(cookies);
      party.add(milk);
      party.add(pop);
      party.add(pizza);
      party.add(iceCream);
      double totalCost = party.getTotalCost();
   
      System.out.println("Items for the party are: \n order of " + cookies + 
         "\n order of " + milk + "\n order of " + pop + 
         "\n order of " + pizza + "\n order of " + iceCream + "\n");
      System.out.println("Total cost of grocery items for the party is $" + totalCost);
      
   }
}
