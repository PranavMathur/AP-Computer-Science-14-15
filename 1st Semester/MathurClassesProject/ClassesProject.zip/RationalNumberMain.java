public class RationalNumberMain
{
   public static void main(String[] args)
   {
      RationalNumber num0 = new RationalNumber();
      RationalNumber num1 = new RationalNumber(3, 8);
      RationalNumber num2 = new RationalNumber(3, 6);
      RationalNumber num3 = new RationalNumber(7, -8);
      RationalNumber num4 = new RationalNumber(-1, 4);
   
      System.out.println("Number 0 is " + num0);
   
      int denom1 = num1.getDenominator();
      int numer1 = num1.getNumerator();
      System.out.println("Number 1 denominator is " + denom1);
      System.out.println("Number 1 numerator is " + numer1);
      System.out.println("Number 1 is " + num1);
   
      RationalNumber result1 = num2.add(num3);
      System.out.println("Addition Result is " + result1);
   
      RationalNumber result2 = num3.subtract(num4);
      System.out.println("Subtraction Result is " + result2);
      
   }
}
